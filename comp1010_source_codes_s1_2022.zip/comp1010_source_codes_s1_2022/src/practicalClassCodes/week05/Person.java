package practicalClassCodes.week05;
public class Person {
	public String name;
	public int age;
}

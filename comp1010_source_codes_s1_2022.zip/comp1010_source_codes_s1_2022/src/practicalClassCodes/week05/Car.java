package practicalClassCodes.week05;
public class Car {
	public String model;
	public int price;
}

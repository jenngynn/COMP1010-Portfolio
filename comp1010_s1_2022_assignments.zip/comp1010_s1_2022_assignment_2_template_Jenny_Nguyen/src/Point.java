/**
 * DO NOT REMOVE THIS COMMENT
 * STUDENT ID: 47158964
 * STUDENT NAME: Jenny Nguyen
 * [x]: add an 'x' inside the square brackets to declare that you haven't seen any other person's code
 */
/**  	 		 	 		 	  					  		 	
 * Point class represents a point in a 2-diemensional plane.
 * 
 * x gives how far right is the point from the origin (0, 0) (negative means to the left)
 * y gives how far up is the point from the origin (0, 0) (negative means below)
 * 
 * @author gauravgupta
 *
 */  	 		 	 		 	  					  		 	
public class Point {
	public int x, y;

	/**  	 		 	 		 	  					  		 	
	 * DO NOT MODIFY
	 * @param x
	 * @param y
	 */  	 		 	 		 	  					  		 	
	public Point(int x, int y) {  	 		 	 		 	  					  		 	
		this.x = x;
		this.y = y;
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * DO NOT MODIFY
	 */  	 		 	 		 	  					  		 	
	public String toString() {  	 		 	 		 	  					  		 	
		return "("+x+","+y+")";
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param other
	 * @return true i the calling object and the parameter object represent the same physical point
	 */  	 		 	 		 	  					  		 	
	public boolean identical(Point other) {
		if (this.x == other.x && this.y == other.y) {
			return true;
		}
		return false;
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * DO NOT MODIFY
	 * 
	 * @param other
	 * @return distance between the calling object and parameter object
	 */  	 		 	 		 	  					  		 	
	public double distance(Point other) {  	 		 	 		 	  					  		 	
		double dx = x - other.x;
		double dy = y - other.y;
		double sumSquared = dx*dx + dy*dy;
		return Math.sqrt(sumSquared);
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return quadrant to which point belongs
	 * For details: read https://en.wikipedia.org/wiki/Quadrant_(plane_geometry)
	 * Assume x=0 is in the right half and y=0 is in the top half
	 */  	 		 	 		 	  					  		 	
	public int getQuadrant() {
		if(this.x >= 0) {//right half
			if(this.y >= 0) {//top half
				return 1;
			}
			return 4;//bottom half
		}
		else {//left half
			if(this.y >= 0) { //top half
				return 2;
			}
			return 3; //bottom half
		}
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param other
	 * @return 
	 * 1 if calling object is further from the origin than the parameter object
	 * -1 if calling object is closer to the origin than the parameter object
	 * 0 if calling object is the same distance from the origin as the parameter object
	 */  	 		 	 		 	  					  		 	
	public int compareTo(Point other) {
		//distance equals pythagoras theorem: c^2 = a^2 + b^2
		//calculate values for calling obejct
		double thisA = this.x*this.x;
		double thisB = this.y*this.y;
		double thisC = thisA + thisB;
		//calculate values for parameter object
		double otherA = other.x*other.x;
		double otherB = other.y*other.y; 
		double otherC = otherA + otherB;
		//compare distance of calling to parameter object
		if(Math.sqrt(thisC) > Math.sqrt(otherC)) { 
			return 1;
		}
		if(Math.sqrt(thisC) < Math.sqrt(otherC)) {
			return -1;
		}
		return 0;//same distance
	}

	/**  	 		 	 		 	  					  		 	
	 * IMPORTANT: neither calling object nor parameter object should be modified!
	 * @param other
	 * @return a Point that represents the calling object shifted by the parameter object.
	 * For example, when you shift (5, 3) by (2, -5), you get (7, -2)
	 */  	 		 	 		 	  					  		 	
	public Point shift(Point other) {  	
		int shiftedX = this.x+other.x;
		int shiftedY = this.y+other.y;
		Point shifted = new Point(shiftedX, shiftedY); 
		return shifted;
	}  	

	/**  	 		 	 		 	  					  		 	
	 * Calling object should NOT be modified.
	 * @return the Point when you flip the plane around the x-axis. 
	 * See tests for samples for better understanding of the problem.
	 */  	 		 	 		 	  					  		 	
	public Point flipXAxis() {  
		Point flippedOnX = new Point(this.x,this.y*-1);
		return  flippedOnX;
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * Calling object should NOT be modified.
	 * @return the Point when you flip the plane around the y-axis. 
	 * See tests for samples
	 */  	 		 	 		 	  					  		 	
	public Point flipYAxis() {  
		Point flippedOnY = new Point(this.x*-1,this.y);
		return flippedOnY;

	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * @param p1
	 * @param p2
	 * 
	 * @return true if calling object lies on the line segment that goes from p1 to p2.
	 * Note 1: that p1 and p2 themselves DO lie on that line.
	 * Note 2: if calling object lies on *projected* line segment, the function should return false.
	 * For example, 
	 * (2, 0) lies on the line segment from (0, 0) to (4, 0)
	 * (1, 2) does not lie on the line segment from (0, 0) to (4, 0)
	 * (12, 0) does not lie on the line segment from (0, 0) to (4, 0)
	 * (0, 0) lies on the line segment from (0, 0) to (4, 0)
	 * (4, 0) lies on the line segment from (0, 0) to (4, 0)
	 */  	 		 	 		 	  					  		 	
	public boolean liesOn(Point p1, Point p2) {
		//x coordinates
		double minX = p1.x;
		double maxX = p2.x;
		//y coordinates
		double minY = p1.y;
		double maxY = p2.y;
		if(this == p1 || this == p2) {
			return true; //calling objects inclusive
		}
		if(minX > maxX) { //change order of min and max for x coordinates
			minX = p2.x;
			maxX = p1.x;
		}

		if(minY > maxY) { //change order of min and max for y coordinates
			minY = p2.y;
			maxY = p1.y;
		}
		if(this.x < minX || this.x > maxX || this.y <minY || this.y > maxY) {
			return false;// calling is outside of range
		} 
		//gradient of lines
		double mOfAB = gradient(p1, p2);
		double mOfAC = gradient(p1, this);

		if(mOfAB == mOfAC) {
			return true; //gradient of p1 and p2 equals gradient of p1 and calling
		}
		return false;
	} 

	/**
	 * helper function
	 * @param a
	 * @param b
	 * @return gradient of line ab
	 */
	public static double gradient(Point a, Point b) {
		double rise = b.y - a.y;
		double run = b.x - a.x;
		if(rise == 0) {
			return 0;
		}
		return rise/run;
	}

}// end whole program code

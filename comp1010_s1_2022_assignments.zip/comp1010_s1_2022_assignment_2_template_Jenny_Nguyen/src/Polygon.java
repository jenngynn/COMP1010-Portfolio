/**
 * DO NOT REMOVE THIS COMMENT
 * STUDENT ID: 47158964
 * STUDENT NAME: Jenny Nguyen
 * [x]: add an 'x' inside the square brackets to declare that you haven't seen any other person's code
 */
public class Polygon {
	public Point[] points;

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param x
	 * @param y
	 * 
	 * Populate the instance variable array, points, using the arrays x and y.
	 * Each corresponding pair in the two arrays; x[i], y[i]; represents one point.
	 * 
	 * use the first n items where n is the smaller of x.length and y.length
	 * 
	 * in case of either array being null, initialize the array to an empty one.
	 */  	 		 	 		 	  					  		 	
	public Polygon(int[] x, int[] y) {
		if(x == null || y == null) {
			points = new Point[0]; // empty array

		}
		else {
			int shorter = x.length; // assume array x is shorter
			if(y.length < shorter) { 
				shorter = y.length;
			}
			points = new Point[shorter];
			for(int i = 0; i< points.length; i++) { //populate array with points
				points[i] = new Point(x[i], y[i]);
			}
		}
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param _points
	 * 
	 * Populate the instance variable array points with items of _points.
	 * 
	 * See the test data to determine null case scenario, etc.
	 * 
	 * Make sure all objects (including arrays) copying is done using instance copy, not reference copy.
	 */  	 		 	 		 	  					  		 	
	public Polygon(Point[] _points) {
		if(_points == null || _points.length == ' ') {
			points = new Point[0]; //empty array
		}
		else {
			points = new Point[_points.length]; // new instance
			for(int i = 0; i<points.length;i++) { //populate with instance copies
				points[i] = new Point(_points[i].x, _points[i].y);
			}//end for
		}
	}  	 		 	 		 	  					  		 	

	//DO NOT MODIFY!
	public String toString() {  	 		 	 		 	  					  		 	

		String result = "("+points[0].x+", "+points[0].y+") -> ";
		for(int i=1; i < points.length; i++) {
			result+="("+points[i].x+", "+points[i].y+") -> ";
		}
		if(points.length > 1)
			result+="("+points[0].x+", "+points[0].y+")";
		else
			result = result.substring(0, result.length()-4);
		return result;
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return index of the first point that has the same values for x and y coordinates
	 * return -1 if no such point exists.
	 */  	 		 	 		 	  					  		 	
	public int firstPointWithSameXY() {
		for(int i = 0; i<points.length;i++) { //compare x to y for each point
			if(points[i].x == points[i].y) {
				return i; // point exists
			}
		}
		return -1; //point does not exist
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return index of the last point that lies on the origin (0, 0)
	 * return -1 if no such point exists.
	 */  	 		 	 		 	  					  		 	
	public int lastPointAtOrigin() { 
		if(points == null) {
			return -1;
		}
		else {
			int index = -1; // hold index of point at origin
			for(int i = 0;i<points.length;i++) {
				if(points[i].x == 0 && points[i].y == 0) {
					index = i;
				}
			}
			return index; //-1 if value of index was not changed
		}
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return true if every point is further from origin than the last point,
	 * false otherwise.
	 */  	 		 	 		 	  					  		 	
	public boolean goingFurtherFromOrigin() { 
		double[] dist = new double[points.length]; //array of distances
		for(int i = 0;i<dist.length;i++) { //populate dist array
			Point p = new Point(0, 0);
			dist[i] = p.distance(p);
			if(dist[i]<dist[i++]) {
				return true;
			}
		}
		return false;
	}  //write own tests

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return the sum of all sides of the polygon
	 * first point to second, 
	 * second point to third,
	 * second last point to last,
	 * last point back to first
	 */  	 		 	 		 	  					  		 	
	public double circumference() { 
		double[] leng = new double[points.length];
		for(int i = 0;i<point)
			return 0;
	}  	 	//write own tests	 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return index of the first point that is on origin (0, 0).
	 * return -1 if no such point exists.
	 */  	 		 	 		 	  					  		 	
	public int firstPointOnOrigin() {  	 		 	 		 	  					  		 	
		if(points == null) {
			return -1;
		}
		else {
			for(int i = 0;i<points.length;i++) {//check values of x AND y are 0
				if(points[i].x == 0 && points[i].y == 0) {
					return i;
				}
			}
			return -1;
		}
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return index of the last point that has the same values for x and y coordinates
	 * return -1 if no such point exists.
	 */  	 		 	 		 	  					  		 	
	public int lastPointWithSameXY() { 
		int index = -1; 

		if(points == null) {
			return 0;
		}
		for(int i = 0; i<points.length;i++) {//check value of x is identical to y
			if(points[i].x == points[i].y) {
				index = i; //store index
			}
		}
		return index;
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 *
	 * An edge is the line between two adjacent vertices/points in a polygon.
	 * @return the length of the longest edge.
	 * For example if there are three consecutive points (2,3) -> (7,3) -> (8,3),
	 * then (2,3) -> (7,3) is one side, and (7,3) -> (8,3) is a second side.
	 */  	 		 	 		 	  					  		 	
	public double longestEdge() { 
		double longest = 0; // holds the largest value
		//double edgeLength = 0;

		double x = 0;
		double xSqr = 0;
		double y = 0;
		double ySqr = 0;
		double d = 0;

		if(points == null) {
			return 0;
		}
		int k = 0;
		for(int i = 0;i<points.length-1;i++) {//compare edges
			k = i++;
			x = points[k].x - points[i].x; //(x2 - x1)
			xSqr = x*x; //(x2 - x1)^2
			y = points[k].y - points[i].y; //(y2 - y1)
			ySqr = y*y; //(x2 - x1)^2
			d = xSqr + ySqr; // d^2 = (x2 - x1)^2 + (y2 - y1)^2
			//double dSqr = Math.sqrt(d);
			//edgeLength = dSqr;
			if(d >= longest) {
				d = longest;
			}

		} //end for
		double firstLastX = points[points.length-1].x - points[0].x;
		double firstLastY = points[points.length-1].y - points[0].y;
		//index 0 and index point.length-1
		d = (firstLastX*firstLastX) + (firstLastY *firstLastY);
		if(d > longest) {
			d = longest;
		}
		return Math.sqrt(longest);
	}  	 

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param minLength
	 * @param maxLength assume maxLength >= minLength
	 * @return number of edges in the polygon that have a length between the two lengths
	 * (inclusive on both sides)
	 */  	 		 	 		 	  					  		 	
	public int countEdgesBetween(int minLength, int maxLength) {  
		int counter = 0; //hold the number of points that fits conditions
		double[] dist = new double[points.length]; //array of distances

		for(int i = 0;i<points.length-2;i++) { //
			Point edge = new Point(points[i++].x, points[i++].y);
			dist[i] = points[i].distance(edge);
			if(dist[i] >= minLength && dist[i] <= maxLength) { //point lies within range
				counter++;
			}
		}
		return counter;
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return index of the point that is closest to the origin, which is (0, 0)
	 * In case of a tie, return the lowest index
	 */  	 		 	 		 	  					  		 	
	public int closestToOriginIndex() { 
		return 0;
	} // write own test  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param q (between 1 and 4)
	 * @return the index of the first point that is in quadrant q.
	 * return -1 if no such point exists.
	 */  	 		 	 		 	  					  		 	
	public int firstPointInQuadrant(int q) {  
		for(int i = 0;i<points.length;i++) {
			Point quad = new Point(points[i].x,points[i].y); //new instance of Point
			if(quad.getQuadrant() == q) {
				return i;
			}
		}
		return -1;
	}  	 		 	 		 	  					  		 	


	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return true if all points of the polygon are in the same quadrant, false otherwise
	 * 
	 */  	 		 	 		 	  					  		 	
	public boolean inSingleQuadrant() {  
		if(points == null) {
			return false;
		}
		int[] quadrant = new int[points.length]; // array of quadrants of each point
		for(int i = 0;i<points.length;i++) {
			Point quad = new Point(points[i].x,points[i].y); //new instance of Point

			quadrant[i] = quad.getQuadrant();
			if(quadrant[i] != quadrant[0]) {
				return false;
			}
		} //end for
		return true;
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param p
	 * @return number of points that are further from the origin than point p is. 
	 */  	 		 	 		 	  					  		 	
	public int countPointsFurtherThan(Point p) {
		//distance from origin to p 
		//distance of origin to points
		//make new array holding distance values
		//iterate through array 
		int counter = 0;
		for(int i = 0;i<points.length;i++) {
			Point further = new Point(points[i].x, points[i].y);
			if(further.compareTo(p) == 1) { //calling point is further from origin
				counter++;
			}
		}
		return counter;
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * @return a 2-dimensional array containing points.length subarrays,
	 * each containing two items.
	 * first subarray contains points[0].x, points[0].y
	 * second subarray contains points[1].x, points[1].y
	 * and so on
	 */  	 		 	 		 	  					  		 	
	public int[][] get2DArray() { 
		int[][] coordinates = new int[points.length][2];
		for(int i = 0;i<coordinates.length;i++) { //row
			for(int k = 0;k<coordinates[i].length;k++) { //colum
				coordinates[i][0] = points[i].x;
				coordinates[i][1] = points[i].y;
			}
		}
		return coordinates;
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * HD - 1
	 * @return number of points that are *essential*.
	 * Now, what is a NON-essential point?
	 * Say, there are three adjacent points on the polygon such that,
	 * points[i].x, points[i].y = 2, 3
	 * points[i+1].x, points[i+1].y = 6, 2
	 * x[i+2], y[i+2] = 14, 0
	 * 
	 * You will notice they all lie on a straight line and that 
	 * (6, 2) lies between (2, 3) and (14, 0).
	 * Hence point (6, 2) can be removed from the polygon 
	 * while maintaining the shape of the polygon,
	 * and is called NON-essential.
	 * 
	 * So, any point that lies on the line segment connecting 
	 * the two points (one before and one after it) is NON-essential
	 */  	 		 	 		 	  					  		 	
	public int countEssentialPoints() { 
		int count = points.length; //holds number of essential points
		for(int i = 0;i<points.length-3;i+=3) {
			Point line = new Point(points[i].x, points[i].y);
			if(line.liesOn(points[i++], points[i+2]) == true) { //calling object and two adjacent points
				count-=2;
			}

		}

		return count;
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * HD - 2
	 * @return a Polygon object containing only essential points.
	 * Note the calling object should not be modified.
	 * Please see test for a better understanding of the problem.
	 */  	 		 	 		 	  					  		 	
	public Polygon getOptimized() {  	 		 	 		 	  					  		 	
		return null;
	}  	 		 	 		 	  					  		 	
}
/**
* DO NOT REMOVE THIS COMMENT
* STUDENT ID: 47158964
* STUDENT NAME: Jenny Nguyen
* [x]: add an 'x' inside the square brackets to declare that you haven't seen any other person's code
*/
package attempts;

public class Chain {
	public Block head;
	public Block tail;
	
	// Attributes to be added

	/**  	 		 	 		 	  					  		 	
	 * Default constructor
	 * 
	 * You may modify this constructor if you need to (e.g. if you want to
	 * initialise extra attributes in the class)
	 */  	 		 	 		 	  					  		 	
	public Chain() {  	 		 	 		 	  					  		 	
		head = null;
		tail = null;
		
		// Attributes to be added
	}  	 		 	 		 	  					  		 	

	// DO NOT MODIFY
	public String toString() {  	 		 	 		 	  					  		 	
		if (head == null) {
			return null;
		}
		return head.toString();
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param id - The first number in the chain
	 * @return a valid Collatz chain starting at id and ending at 1. The chain
	 *         shouldn't contain any loops. If the given id is non-positive, return
	 *         null. There are 2 tests for this method, one to check your logic (P)
	 *         and another to check the efficiency of the code (HD).
	 */  	 		 	 		 	  					  		 	
	public Block createChain(int id) { 
		int rank = 1;
		//first block
		Block first = new Block(id, rank);
		head = first;
		tail = first;
		return addBlock(head, tail, id, rank);
	}
	
	private Block addBlock(Block head, Block tail, int id, int rank) {
		if(id <=0) {
			return null;
		}
		else if(id == 1) { // base case
			return head;
		} else { // recursion
			if(isEven(id)) {
			Block nextB = new Block(id/2, rank+1);
			tail.next = nextB;
			return addBlock(head, tail.next, id/2, rank+1);
			} else { //id is odd
				Block nextB = new Block(id*3 +1, rank+1);
				tail.next = nextB;
				return addBlock(head, tail.next, id*3+1, rank+1);
			}
		}
	}
	
	private boolean isEven(int value) {
		return value %2 ==0;
	}
	
	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return the number of Blocks in the chain. There are 2 tests for this method,
	 *         one to check your logic (P) and another to check the efficiency of
	 *         the code (HD).
	 */  	 		 	 		 	  					  		 	
	public int size() { 
		if(head == null) {
			return 0;
		}
		return sizeHelper(head, 0);
	}
	
	private int sizeHelper(Block b, int count) {
		if(b.next == null) { //base case
			return count+1;
		} else {
			return sizeHelper(b.next, count+1);
		}
	}

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return the Block that contains the highest id in the Chain. If there aren't
	 *         any Blocks in the chain, return null.
	 */  	 		 	 		 	  					  		 	
	public Block maxValue() {  
		if(head == null) {
			return null;
		}
		int max = head.id; //max currently holds value for the first Block
		tail = maxVal(head, head, max);

		return tail;
	} 
	
	//helper
	private Block maxVal(Block head, Block tail, int max) {
		if(head == null) { // no Blocks
			return null;
		}
		else if(head.next == null) { // base case
			return tail;
		} else {
			if(head.id > max) {
				tail = head;
				return maxVal(head.next, tail, tail.id);
			}
			return maxVal(head.next, tail, max);
		}
	}
	

	/**
	* 
	* @param id - The first number in the chain
	* @return a faster Collatz chain which skips the number following an even number.
	*         It should follow the 3n+1/2 rule directly, as 3n+1 is always even.
	*         The chain shouldn't contain any loops. If the given id is
	*         non-positive, return null. Do not modify the original Chain.
	 */	 		 	 		 	  					  		 	
	public Chain createFasterChain(int id) { 
		return null;
	}  
	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param other
	 * @return the id of the first common block between the two Chains. If there is
	 *         no common block, return null. If the ranks differ, return the one
	 *         with the higher rank.
	 */  	 		 	 		 	  					  		 	
	public Block firstCommonBlock(Chain other) { 
		
		return null;
	}  	 		 	 		 	  					  		 	
	
	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param id - ID to be removed
	 * @return the removed Block. If there doesn't exist a Block with the given ID,
	 *         return null. If a Block is removed, the rank of all the Blocks after
	 *         it needs to be updated to ensure there isn't a gap in ranking.
	 */  	 		 	 		 	  					  		 	
	public Block removeId(int id) { 
		return null;
	}  

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return a Chain where all the Blocks in the current chain is sorted in
	 *         ascending order. Do not modify the calling object.
	 */  	 		 	 		 	  					  		 	
	public Chain Sort() {  	
		// create duplicate chain
		Chain asc = new Chain();
		asc.head = this.head;
		asc.tail = this.tail;
		
		if(head == null) {//empty chain
			return null;
		}
		if(head.next == null);
		
		return null;
	}


	/**  	 		 	 		 	  					  		 	
	 * 
	 * @param min
	 * @param max
	 * @return the seed (id) in the interval [min, max] that gives the longest
	 *         chain. Only positive seed should be considered. If the interval is
	 *         invalid, return null.
	 */  	 		 	 		 	  					  		 	
	public Chain longestChain(int min, int max) {  	 		 	 		 	  					  		 	
		return null;
	}  	 		 	 		 	  					  		 	

}

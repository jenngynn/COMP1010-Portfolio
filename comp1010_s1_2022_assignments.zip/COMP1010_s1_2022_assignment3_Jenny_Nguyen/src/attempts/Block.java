/**
* DO NOT REMOVE THIS COMMENT
* STUDENT ID: 47158964
* STUDENT NAME: Jenny Nguyen
* [x]: add an 'x' inside the square brackets to declare that you haven't seen any other person's code
*/
package attempts;


public class Block {
	public int id; // Number
	public int rank; // position in the Chain
	public Block next; // points to the next block
	// attributes to be added
	public int size;

	public Block(int id, int rank) {  	 		 	 		 	  					  		 	
		this.id = id;
		this.rank = rank;
		this.next = null;
		// attributes to be added
	}  	 		 	 		 	  					  		 	
	
	public Block(int id, int rank, Block next) {  	 		 	 		 	  					  		 	
		this.id = id;
		this.rank = rank;
		this.next = next;
		// attributes to be added
	}   	 
	
	// Additional constructors may be added
	public boolean isEven() {
		return id % 2 == 0;
	}
	// DO NOT MODIFY
	public String toString() {  	 		 	 		 	  					  		 	
		String str = "(" + id + ", " + rank + ")";
		if (this.next == null) {
			return str;
		}
		return str + " -> " + next.toString();
	}  	 		 	 		 	  					  		 	

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return the number of Blocks in the Chain that has an even ID.
	 */  	 		 	 		 	  					  		 	
	public int numberEvenBlocks() { 
		return evenBlocksHelper(this);
		
	} 
	
	private int evenBlocksHelper(Block b) {
		if(b == null) { //end of the chain
			return 0;
		}
		if(b.id % 2 == 0) { //add 1 and continue iteration
			return 1 + evenBlocksHelper(b.next);
		} else { // id is odd
			return evenBlocksHelper(b.next);
		}
	}
		
	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return the number of Blocks in the Chain that has an odd ID.
	 */  	 		 	 		 	  					  		 	
	public int numberOddBlocks() {  
		return oddBlocksHelper(this);
	}  	
	
	private int oddBlocksHelper(Block b) {
		if(b == null) {
			return 0;
		}
		if(b.id % 2 != 0) {
			return 1 + oddBlocksHelper(b.next);
		}
		return oddBlocksHelper(b.next);
	}

	/**  	 		 	 		 	  					  		 	
	 * 
	 * @return true if the chain starting at the current node is a valid Collatz
	 *         chain and false otherwise. For a chain to be valid, it needs to
	 *         follow the 3n+1 rule but not necessarily have a valid rank. The fast
	 *         collatz chain should be treated as invalid.
	 */  	 		 	 		 	  					  		 	
	public boolean isValid() {
		Block curr = this;
		//3n+1 is always even so following every odd numebr should always be even
		if(this == null) {
			return false;
		}
		while(curr != null && curr.next != null) {
			if(curr.id % 2 == 0 || curr.next.id % 2 == 0) {
				curr = curr.next;
			} else { // there are two odd numbers in a row
			return false;
			}
		}
		return true;
	}
		


	/**  	 		 	 		 	  					  		 	
	 * IMPORTANT: Even thought this method is in the Block class, it may be harder
	 * than most in the Chain class.
	 * 
	 * @return true if the chain starting at the current node is either a valid
	 *         Collatz chain or a fast Collatz chain. In this question, you also
	 *         need to ensure that the rank is valid. A valid rank starts at 1 and
	 *         increases with one.
	 */  	 		 	 		 	  					  		 	
	public boolean isValidAdvanced() {  	 		 	 		 	  					  		 	
		return false;
	}  	 		 	 		 	  					  		 	
}

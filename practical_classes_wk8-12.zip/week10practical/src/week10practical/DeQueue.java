package week10practical;
import java.util.ArrayList;

public class DeQueue {
    public ArrayList<String> items;

    public DeQueue() {
        items = new ArrayList<String>();
    }

    public void insertAtEnd(String item) {
        items.add(item); // insert at the back
    }
    public void insertAtFront(String item) {
    	items.add(0, item);
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public String removeFromFront() {
        if (isEmpty()) {
            return null;
        } else {
            return items.remove(0); // remove from the front
        }
    }
    public String removeFromEnd() {
    	if(isEmpty()) {
    		return null;
    	} else {
    		return items.remove(items.size()-1);
    	}
    }
    
    

    public String toString() {
        return items.toString();
    }
}
package week10practical;
import java.util.ArrayList;

public class MyStack {
    public ArrayList<String> items;
    public int nItems = 0;

    public MyStack() {
        items = new ArrayList<String>();
        nItems = 0;
    }
  //Question 4
    public MyStack (MyStack source) {
    	items = new ArrayList<String>();
    	for(int i = source.nItems-1;i>=0;i--) {
    		String s = source.items.get(i);
    		this.push(s);
    	}
    	nItems = source.nItems;
    }

    public void push(String item) {
        items.add(0, item);
        nItems++;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public String pop() {
        if (isEmpty()) {
            return null;
        } else {
            nItems--;
            return items.remove(0);
        }
    }

    public String toString() {
        return items.toString();
    }
    
    //Qeustion 2
    public String peak() {
    	if(isEmpty()) {
    		return null;
    	}
    	return items.get(0);
    }
    //QUestion 3
    public void clear() {
    	while(!isEmpty()) {
    		items.remove(0);
    		//OR  items.pop();
    	}
    	nItems = 0;
    	return;
    }
    
    //question 5
    public int size() {
    	return nItems;
    }
    
 
    
}
package week12practical;

import org.w3c.dom.Node;

public class Client {
	public static void main(String[] args) {
		CustomLinkedList list = new CustomLinkedList();
		list.addToFront(90);
		list.addToFront(10);
		list.addToFront(40);
		list.addToFront(60);
	}
	
	class CustomLinkedList {
		public Node head ; // == null (default)
		
		public void addToFront(int val) {
			head = new Node(val, head);
		}
		
		public String toString() {
			if(head == null) {
				return "";
			}
			return head.toString();
		}
	}
	public Node firstOdd() {
		Node curr = head;
		while(curr != null) { // traversing
			if(curr.data % 2 !=0) {
				return curr; // break; <-- go straight to the return
			}
			curr = curr.next;
		}
		return null; // return curr;
	}
}
package week09practical;

public class MyLinkedListClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyLinkedList myList = new MyLinkedList();
		myList.addToFront("Bernard");
		
		System.out.println(myList);
	}

}

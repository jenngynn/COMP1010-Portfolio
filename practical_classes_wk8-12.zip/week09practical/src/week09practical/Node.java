package week09practical;

public class Node {
	
	public String data; //storage
	public Node next; //access the rest
	
	public Node() {
		data = null;
		next = null;
	}
	
	public Node (String s) {
		data = s;
		next = null;
	}
	
	public Node (String s, Node n) { // create new block and attach it to node n
		data = s;
		next = n;
	}
	
	/**
	 * print the complete chai nstarting from this Node
	 *
	 */
	public String toString() {
		if (next == null) {
			return data;
		}
		return data + "->";
	}
}

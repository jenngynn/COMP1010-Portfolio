package week09practical;

public class MyLinkedList {
	public Node head; //most important
	//you can have as many nodes as you want, but a head will give you the access
	//to the actual linked list
	//do not change
	
	
	//access
	
	public MyLinkedList() { //empty
		head = null;
	}
	
	/**
	 * Create a new Node containing s and attach it to the head
	 * @param s
	 */
	public MyLinkedList(String s) {
		Node node = new Node(s);
		setHead(node);
	}
	
	public void addToFront(String s) { //change the head
		Node node = new Node(s);
		
//		//if the node is the first existing node
//		if(head == null) {
//			head = node;
//		}
//		//if there is existing nodes
//		node.next = head; // attach the node to the head
//		head = node;//change the head
//		
		if(!isEmpty()) { //head!=null
			node.next = head;
		}
	}
	/**
	 * DOES NOT modify the LinkedList
	 * @return head
	 */
	public Node getHead() {
		return head;
	}
	
	public void setHead(Node head) {
		this.head = head;
	}
	
	//test empty
	public boolean isEmpty() {
		if (head == null) {
		return true;
	}
	return false;
	}
	
	public String toString() {
		Node curr = head; //always acreate a variable to manipulate the chain
		//iterator
		String result = "";
		while(!isEmpty()) {
			result = result + curr.data + " ";
			curr = curr.next;
		}
		return result;
	}
	
}

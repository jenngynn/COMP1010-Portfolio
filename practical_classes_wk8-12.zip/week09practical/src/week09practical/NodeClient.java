package week09practical;

public class NodeClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Node a = new Node("");
		Node head = new Node("Nataly", new Node("Gaurav", new Node("Bernad", null)));
		System.out.println(head);
		
		Node curr = head;
		//for(int i =0;i<length;i++) {
		while (curr.next !=null) {
			//do something
			System.out.println(curr.data);
			curr = curr.next; // iteration this destroys the information about he head of the list
			//never let go of the head/first link in the chain
			
		}
	}
	

}

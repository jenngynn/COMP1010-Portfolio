import java.util.ArrayList;

public class Q4 {
	public static void main (String[] args) {

	
}
public static void sort(int[] data) {
	for(int i=0; i < data.length; i++) {
		int mystery = i;
		for(int k=i+1; k < data.length; k++) {
		
			if(data[k] < data[mystery]) {

				mystery = k;

			}
		}
		int temp = data[i];
		data[i] = data[mystery];
		data[mystery] = temp;
	}
}
//q5
public static void sort(int[] data) {
	for(int i=0; i < data.length; i++) {
		int mystery = i;
		for(int k=i+1; k < data.length; k++) {
		
			if(data[k] > data[mystery]) {

				mystery = k;

			}
		}
		int temp = data[i];
		data[i] = data[mystery];
		data[mystery] = temp;
	}
}
public static int[] getSorted(int[] data) {
	int[] result = new int[data.length]; // how many items should be included?
	for(int i = 0;i<result.length;i++) {
		result[i] = data[i];
	}
	sort(result); // from the previous question
	
	system.out.println(data);// one or more statements allowed
	system.out.println(result);
}



//Q6
public static void sort(int[] data) {
	for(int i=1; i < data.length; i++) {
		insertAtRightPlace(data, i);
	}
}

/**
 * @param data: array to operate on
 * @param idx: item to be moved into the right index
 * 
 * Assuming data is sorted in ascending order from index 0 
 * to index idx-1, insert the item at index idx into the right
 * place between indices 0 and idx, such that after the function terminates, 
 * the array is sorted in ascending order from 
 * index 0 to index idx
*/
public static void insertAtRightPlace(int[] data, int idx) {
	int smallest = idx;
	for(int i = i+idx;i<data.length;i++) {
		if (data[i]< data[smallest]) { // idx is the smallest value
			smallest = i;
			
		}
		
	}
	int temp = data[idx];
	data[smallest] = data[idx];
	data[idx] = temp;
	

	// Complete this function!
}

//q8
public static void sort(ArrayList<Rectangle> data) {
	for(int i=0; i < data.size() ; i++) {
		int minIndex = i;
		for(int k=i+1; k < data.size(); k++) {
			if(data.get(k).compareTo(data.get(minIndex)) == -1) {
				minIndex = k;
			}
		}
		// swap items at indices i and minIndex
		Rectangle temp = data.get(i);
		data.set(i, data.get(minIndex));
		data.set(minIndex, temp);
		
	}
}
}
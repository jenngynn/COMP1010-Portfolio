
public class gl {
		   public static void main(String[] args) {
		        System.out.println(foo("alienate"));
		    }

		    public static int foo(String s) {
		        if(s.length() < 2)
		            return 0;
		        char ch = s.charAt(0);
		        if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
		            return 1 + foo(s.substring(2));
		        else
		            return foo(s.substring(1));
		    }
		
}

import java.util.ArrayList;

public class Client {

	public static void main(String[] args) {
		ArrayList<String> words = new ArrayList<String>();
		words.add("I");
		words.add("solemnly");
		words.add("swear");
		words.add("that");
		words.add("I");
		words.add("am");
		words.add("upto");
		words.add("no");
		words.add("good.");
		
		System.out.println("Number of items in list: " + words.size());
		
		System.out.println("Item 5 in the list is: " + words.get(4));
		
		System.out.println("Last item in the list: "+words.get(words.size()-1));
		
		words.set(4,"Done");
		
		System.out.println("Removed item: " + words.get(1));
		words.remove(1);
		
		words.set(4, "are");
		System.out.println(words);
		
		words.add(words.size()-1, "real");
		System.out.println(words);
		
		int lengthyWordCount = 0;
		for(String item: words) {
			if(item.length() > 4) {
				lengthyWordCount++;
			}
		}
		System.out.println(lengthyWordCount);
	
		ArrayList<Integer> outcomes = new ArrayList<Integer>(12);
		//
		int[] nums = {6, 10, 8, 2, -5, 0, -12, 2, 3, 10, 2, -5};
		for(int i = 0; i< nums.length;i++) {
			outcomes.add(nums[i]);
		}
		
		int countNegatives = 0;
		for(Integer item: outcomes) {
			if(item < 0) {
				countNegatives++;
			}
		}
		System.out.println(countNegatives);
		
		//Q13
		boolean hasNeg = false;
		
		for(Integer item: outcomes) {
			if(item < 0) {
				hasNeg = true;
			}
		}
		
		//Q14
		boolean hasOverTen = false;
		
		for(Integer item: outcomes) {
			if(item <10) {
				hasOverTen = true;
			}
		}
		System.out.println("True?: "+hasOverTen);
		//Q15
		boolean allPos = false;
		allPos = allPositives(outcomes);
		
		boolean allPosNull = false;
		allPosNull = allPositives(null);

	}
	
	
	/**
	 * 
	 * @param list
	 * @return true if all items in the list are positive
	 * IMPORTANT: 
	 * return false if list is null
	 * return true if list is empty
	 */
	public static boolean allPositives(ArrayList<Integer> list) {
		if(list == null)
			return false;
		for(Integer item: list) {
			if(item <= 0) { //<= means NOT positive
				return false;
			}
		} //end of loop
		return true;
	}

	/**
	 * 
	 * @param list
	 * @return true if all items in the list are even (divisible by 2)
	 * IMPORTANT: 
	 * return false if list is null
	 * return true if list is empty
	 */
	public static boolean allEven(ArrayList<Integer> list) {
		return false; //to be completed
	}
	
	//countInRange goes here
	
	/**
	 * 
	 * @param list
	 * modify the list so that each item becomes the square of its previous value
	 */
	public static void squared(ArrayList<Integer> list) {
		//to be completed
	}
	
	public static void removeNegatives(ArrayList<Integer> list) {
		//to be completed
	}
	
	public static ArrayList<Integer> getExclusiveItems(ArrayList<ArrayList<Integer>> list) {
		return null; //to be completed
	}
}